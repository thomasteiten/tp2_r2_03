public class Carre {

    public static void main(String[] args) {

        try {
            int i = Integer.parseInt(args[0]);
            int carre = i * i;

            System.out.println("i x i = " + carre);
        }  catch(ArrayIndexOutOfBoundsException e1) {
                System.err.println("ERREUR : pas de parametre");
                System.exit(1);
        }  catch(NumberFormatException e2) {
                System.err.println("ERREUR : parametre incorrect " + args[0]);
                System.exit(1);
        }
    }
}// Carre


// Exercice 1 : 
/* Exceptions :
1) ArrayIndexOutOfBoundsException ; classe : java.lang.Exception
2) NumberFormatException ; classe : java.lang.Exception */
